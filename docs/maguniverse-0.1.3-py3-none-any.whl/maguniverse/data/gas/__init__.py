# paper sources
from maguniverse.data.gas.sources import gas_sources
# getters
from maguniverse.data.gas.jijina1999 import get_jijina1999

__all__ = [ "gas_sources",
            "get_jijina1999"]

