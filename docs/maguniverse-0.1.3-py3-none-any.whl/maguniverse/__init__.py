import os
__parent_dir__ = os.path.dirname(os.path.abspath(__file__))