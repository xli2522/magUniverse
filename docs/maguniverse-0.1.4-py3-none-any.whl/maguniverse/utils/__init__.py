from maguniverse.utils.fetch_ascii import get_default_data_paths, get_ascii

__all__ = [
    'get_default_data_paths', 
    'get_ascii'
]